class Planet extends PIXI.Sprite {
    constructor(name, x, y, scale, texture, speed) {
        super(app.loader.resources[texture].texture);
        this.anchor.set(0.5, 0.5);
        this.scale.set(scale);
        this.x = x;
        this.y = y;
        this.currentAngle = Math.random() * 2 * Math.PI; // in radians
        this.speed = speed;
        this.name = name;
        this.currentScale = scale;
    }
    selected(){
        this.currentScale *= 2;
        BringToFront(this);
        console.log("Planet selected: " + this.name)
    }
    deselected(){
        this.currentScale /= 2;
    }
    focused(parentScene, currentScene, planet){
        // throw new Error("Not implemented"); // Zoom into planet and show info
        // TODO: KNOWN ISSUE: when you click on a planet, the scene is empty. 
        let planetInfo = new PIXI.Container();
        console.log(planet.name + " is focused");
        parentScene.addChild(planetInfo);

        planetInfo.addChild(planet);

        currentScene.visible = false;
        planetInfo.visible = true;
    }
    update(radius = 100, dt = 1 / 12) {
        const centerX = 1024 / 2;
        const centerY = 768 / 2;

        // set scale every frame
        this.scale.set(this.currentScale);

        if (this.currentAngle > 0) {
            this.currentAngle -= this.speed * dt;
        }
        else {
            this.currentAngle = Math.PI * 2;
        }

        this.x = centerX + Math.cos(this.currentAngle) * radius;
        this.y = centerY + Math.sin(this.currentAngle) * radius;

        
        
        /* old code
        // Calculate the new position of the planet
        const angle = speed * dt;
        const x = centerX + Math.cos(angle) * radius;
        const y = centerY + Math.sin(angle) * radius;

        // Update the position of the planet
        this.x = x;
        this.y = y;
        */
    }
}
class Background extends PIXI.Sprite {
    constructor(x = 512, y = 384) {
        super(app.loader.resources["images/background.png"].texture);
        this.anchor.set(0.5, 0.5);
        this.x = x;
        this.y = y;
    }
}
class Orbits extends PIXI.Graphics {
    constructor(x, y, radius) {
        super();
        this.radius = radius;
        this.lineStyle(2, 0xFFFFFF);
        this.drawCircle(x, y, radius);
        this.endFill();
    }
}